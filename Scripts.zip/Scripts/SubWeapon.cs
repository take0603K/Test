using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SubWeapon : MonoBehaviour
{
    //�N�i�C�p
    [SerializeField] GameObject player = null;
    [SerializeField] GameObject kunai = null;
 
    Rigidbody2D kunaiRd;

    //�u�[�������p

    [SerializeField] GameObject boomerang = null;
    [SerializeField] GameObject boomerangTraget = null;
    private float boomerangSpeed = 10f;
    private Vector3 _boomerangPos;

    bool existsBoomerang = false;
    bool shouldBoomerangRe = false;
    bool needBoomerang = false;

    //���܂������p

    [SerializeField] GameObject kamaitachi = null;

    //����

    private Vector2 _playerPos;
    PrayerC playerScript;

  

    private float startAt;
    void Start()
    {
        _playerPos = player.transform.position;
        kunai.transform.position = _playerPos;
        playerScript = player.GetComponent<PrayerC>();


        boomerang.SetActive(false);
        kamaitachi.SetActive(false);

       
    }
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.E))
        {
            KunaiWeapon();
        }
        if (Input.GetKeyDown(KeyCode.Q))
        {
            BoomerangWeapon();
        }
        if(Input.GetKeyDown(KeyCode.W))
        {
            KamaitachiWeapon();
        }
        if (existsBoomerang == true)
        {
            BoomerangOperation();
        }
       
    }

    private void KamaitachiWeapon()
    {
        Time.timeScale = 0f;
        TestCoroutine(2);
        kamaitachi.SetActive(true);
    }
    IEnumerator TestCoroutine(float time)
    {
        print("�R���[�`��");
        yield return new WaitForSeconds(time);
      
    }
    private void BoomerangWeapon()
    {
        _playerPos = player.transform.position;
        boomerang.SetActive(true);
        boomerangSpeed = 10;
        boomerang.transform.position = _playerPos;
        _boomerangPos = boomerangTraget.transform.position;
        existsBoomerang = true;
    }
    private void BoomerangOperation()
    {
        if (shouldBoomerangRe)
        {
            if(needBoomerang)
            {              
                boomerangSpeed = boomerangSpeed + 2;
                needBoomerang = false;
            }
            _boomerangPos = player.transform.position;
            boomerang.transform.position = Vector2.MoveTowards
                (boomerang.transform.position, _boomerangPos, boomerangSpeed * Time.deltaTime);
        }
        else
        {
            //�u�[���������ڂ̋O��
            boomerang.transform.position = Vector2.MoveTowards
           (boomerang.transform.position, _boomerangPos, boomerangSpeed * Time.deltaTime);
        }   
        if (boomerang.transform.position == _boomerangPos)
        {
            shouldBoomerangRe = true;
            needBoomerang = true;
        }
     
    }
     private void KunaiWeapon()
    {
        _playerPos = player.transform.position;
        float _time=1f;
        print("����");
        GameObject newkunai = Instantiate(kunai);
        kunaiRd = newkunai.GetComponent<Rigidbody2D>();
        newkunai.transform.position = _playerPos;

        if (playerScript.rightNow == true)
        {
            this.kunaiRd.AddForce(new Vector2(1500f, 0f));
        }
        else
        {
            this.kunaiRd.AddForce(new Vector2(-1500f, 0f));
        }
        Destroy(newkunai, _time);
    }
 
}



