using System.Collections;
using System.Collections.Generic;
using UnityEditor.Timeline.Actions;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.UIElements;

public class PrayerC : MonoBehaviour
{ 
    Rigidbody2D rigid2D;
    //�ő��X�s�[�h
    [SerializeField] float _LimitSpeed=15f;
    [SerializeField] float jump = 400f;
    //�ړ��X�s�[�h
    private float move = 40f;
    //���n����
     bool isGround = false;
     bool doubleJump=false;
     public bool rightNow=true;
     bool dash=false;
     int dashCnt;
    [SerializeField] private LayerMask groundLayer;
    private float F = 1.5f;
   // [SerializeField] bool PlayMain = true;

    [SerializeField]
    private AudioClip jumpSound;
    private AudioSource audioSource;
    //private bool sound = true;

    void Start()
    {
        this.rigid2D = GetComponent<Rigidbody2D>();

        audioSource = GetComponent<AudioSource>();
    }

    // Update is called once per frame

    private void FixedUpdate()
    {
        Ray2D ray = new Ray2D(transform.position, Vector2.down);
       // RaycastHit2D hit;
        //���n���菈��
        if (Physics2D.Raycast((Vector2)ray.origin,(Vector2)ray.direction,F,groundLayer))
        {
            isGround = true;
            doubleJump = true;
            dashCnt = 3;
        }
        else
        {
            isGround = false;
        }

        if (Input.GetKey(KeyCode.S))
        {
            this.rigid2D.AddForce(new Vector2(0, -10));
        }

        //���݂̑��x���L�^����
        float speedX = Mathf.Abs(this.rigid2D.velocity.x);
        //�ړ�����

        if (dash)
            return;
        this.rigid2D.AddForce(new Vector2(0f, -5f));
        if (speedX < this._LimitSpeed)
        {
            if (Input.GetKey(KeyCode.D))
            {
                this.rigid2D.AddForce(new Vector2(move, 0f));             
              
                if(rightNow==false)
                {
                    this.gameObject.transform.Rotate(0, 180, 0);
                    rightNow = true;
                }
            
            }
            if (Input.GetKey(KeyCode.A))
            {
                this.rigid2D.AddForce(new Vector2(-move, 0f));
                if (rightNow==true)
                {
                    this.gameObject.transform.Rotate(0, 180, 0);
                    rightNow = false;
                }
            }
        }

        
      
    }
    private void Update() 
    {     
        //�X�y�[�X�L�[�������ꂽ�Ƃ��W�����v����
        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (isGround)
            {
                rigid2D.velocity = Vector3.zero;
                this.rigid2D.AddForce(new Vector2(0f, jump));            
            }
            else if(doubleJump)
            {
                rigid2D.velocity = Vector3.zero;
                this.rigid2D.AddForce(new Vector2(0f, jump));
                doubleJump = false;
            }
         
        }

        if(Input.GetKeyDown(KeyCode.R)&&dashCnt>0)
        {
            rigid2D.velocity = Vector3.zero;
            dash = true;
            if (rightNow)
            {
                this.rigid2D.AddForce(new Vector2(180f, 0f));
            }
            else
            {
                this.rigid2D.AddForce(new Vector2(-180f, 0f));
            }
            dashCnt = dashCnt - 1;
            Invoke("DashStop", 0.25f);
        }
    }
    private void DashStop()
    {
        rigid2D.velocity= Vector2.zero;
        dash = false;
    }
    //private void OnTriggerStay2D(Collider2D collision)
    //{
    //    if(collision.gameObject.tag=="Move")
    //    {
    //        transform.parent = collision.gameObject.transform;
    //    }
    //}
    //private void OnTriggerExit2D(Collider2D collision)
    //{
    //    transform.parent = null;
    //}

}
